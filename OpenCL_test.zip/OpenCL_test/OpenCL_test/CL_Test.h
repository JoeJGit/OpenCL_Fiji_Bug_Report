#pragma once

#include "CL_Helper.h"
#include <assert.h>




struct CL_Test
{
	enum // buffers
	{
		bDBG,
		bNUM,
	};
	
	enum // shaders
	{
		pPRFIX_SUM,
		pNUM,
	};

	CL_Helper::Factory factory;

	cl_program programs[pNUM];
	cl_kernel kernels[pNUM];
	cl_mem buffers[bNUM];

	CL_Test ()
	{
		cl_int status = 0;
		// init ...
		CL_Helper::InitOpenCL(factory);

		programs[pPRFIX_SUM]	= CL_Helper::Compile (factory, "..\\kernels\\prefix_sum.cl");
		kernels[pPRFIX_SUM]		= CL_Helper::CreateKernel (programs[pPRFIX_SUM], "PrefixSum", factory.device_id);
		
		buffers[bDBG]			= clCreateBuffer (factory.context, CL_MEM_READ_WRITE, 1024 * sizeof(int32_t), NULL, &status);

		CL_Helper::CheckError (status); status = 0;
	}

	~CL_Test ()
	{
		// todo: cleanup
	}

	void DownloadBuffers ()
	{
		cl_int status = 0;
		size_t size = 1024 * sizeof(int32_t);
		void *temp = (void*)_aligned_malloc (size, 16);
		assert (temp);

		{
			clEnqueueReadBuffer (factory.command_queue, buffers[bDBG], CL_TRUE, 0, 1024*sizeof(uint32_t), temp, 0, NULL, NULL);
			int32_t *src = (int32_t*) temp;
			for (int i=0; i < 512; i+=8) // todo: needs less
			{
				//base_debug::logF->PrintV ("%4i : %4i %4i %4i %4i %4i %4i %4i %4i", i, src[i], src[i+1], src[i+2], src[i+3], src[i+4], src[i+5], src[i+6], src[i+7]);
				SystemTools::Log ("%4i : %4i %4i %4i %4i %4i %4i %4i %4i\n", i, src[i], src[i+1], src[i+2], src[i+3], src[i+4], src[i+5], src[i+6], src[i+7]);
			}			
			
		}

		_aligned_free (temp);
	}


	void Execute ()
	{
		cl_int status = 0;
		cl_uint param;

		size_t local_item_size = 128;
		size_t global_item_size = local_item_size;//local_item_size * scene.PLLists[scene.interrefletionList + bin].levelIndex[0];

		param = 0;
		cl_kernel kernel;

		kernel = kernels[pPRFIX_SUM];
		status |= clSetKernelArg (kernel, param++, sizeof(cl_mem), &buffers[bDBG]);


		status |= clEnqueueNDRangeKernel (factory.command_queue, kernel, 1, NULL, &global_item_size, &local_item_size, 0, NULL, NULL);
		CL_Helper::CheckError (status, "PrefixSum"); status = 0;
		status = clEnqueueBarrier (factory.command_queue);
		CL_Helper::CheckError (status); status = 0;

		clFinish (factory.command_queue); 
	}

};