// OpenCL_test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "SystemTools.h"
#include "CL_Test.h"


int main()
{
	SystemTools::SetLogFile ("log.txt");

	CL_Test test;
	test.Execute ();
	test.DownloadBuffers ();
    return 0;
}

