#pragma once

#include <CL/cl.h>
#include <CL/cl.hpp>

#include "SystemTools.h"




#include <fstream>

namespace CL_Helper
{
	struct Factory
	{
		cl_device_id device_id;
		cl_context context;
		cl_command_queue command_queue;
		bool ready;

		Factory ()
		{
			cl_device_id device_id = NULL;
			cl_context context = NULL;
			cl_command_queue command_queue = NULL;
			ready = false;
		}
	};



	static const char* GetErrorString (cl_int error)
	{
		switch (error)
		{
			// run-time and JIT compiler errors
			case 0: return "CL_SUCCESS";
			case -1: return "CL_DEVICE_NOT_FOUND";
			case -2: return "CL_DEVICE_NOT_AVAILABLE";
			case -3: return "CL_COMPILER_NOT_AVAILABLE";
			case -4: return "CL_MEM_OBJECT_ALLOCATION_FAILURE";
			case -5: return "CL_OUT_OF_RESOURCES";
			case -6: return "CL_OUT_OF_HOST_MEMORY";
			case -7: return "CL_PROFILING_INFO_NOT_AVAILABLE";
			case -8: return "CL_MEM_COPY_OVERLAP";
			case -9: return "CL_IMAGE_FORMAT_MISMATCH";
			case -10: return "CL_IMAGE_FORMAT_NOT_SUPPORTED";
			case -11: return "CL_BUILD_PROGRAM_FAILURE";
			case -12: return "CL_MAP_FAILURE";
			case -13: return "CL_MISALIGNED_SUB_BUFFER_OFFSET";
			case -14: return "CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST";
			case -15: return "CL_COMPILE_PROGRAM_FAILURE";
			case -16: return "CL_LINKER_NOT_AVAILABLE";
			case -17: return "CL_LINK_PROGRAM_FAILURE";
			case -18: return "CL_DEVICE_PARTITION_FAILED";
			case -19: return "CL_KERNEL_ARG_INFO_NOT_AVAILABLE";

			// compile-time errors
			case -30: return "CL_INVALID_VALUE";
			case -31: return "CL_INVALID_DEVICE_TYPE";
			case -32: return "CL_INVALID_PLATFORM";
			case -33: return "CL_INVALID_DEVICE";
			case -34: return "CL_INVALID_CONTEXT";
			case -35: return "CL_INVALID_QUEUE_PROPERTIES";
			case -36: return "CL_INVALID_COMMAND_QUEUE";
			case -37: return "CL_INVALID_HOST_PTR";
			case -38: return "CL_INVALID_MEM_OBJECT";
			case -39: return "CL_INVALID_IMAGE_FORMAT_DESCRIPTOR";
			case -40: return "CL_INVALID_IMAGE_SIZE";
			case -41: return "CL_INVALID_SAMPLER";
			case -42: return "CL_INVALID_BINARY";
			case -43: return "CL_INVALID_BUILD_OPTIONS";
			case -44: return "CL_INVALID_PROGRAM";
			case -45: return "CL_INVALID_PROGRAM_EXECUTABLE";
			case -46: return "CL_INVALID_KERNEL_NAME";
			case -47: return "CL_INVALID_KERNEL_DEFINITION";
			case -48: return "CL_INVALID_KERNEL";
			case -49: return "CL_INVALID_ARG_INDEX";
			case -50: return "CL_INVALID_ARG_VALUE";
			case -51: return "CL_INVALID_ARG_SIZE";
			case -52: return "CL_INVALID_KERNEL_ARGS";
			case -53: return "CL_INVALID_WORK_DIMENSION";
			case -54: return "CL_INVALID_WORK_GROUP_SIZE";
			case -55: return "CL_INVALID_WORK_ITEM_SIZE";
			case -56: return "CL_INVALID_GLOBAL_OFFSET";
			case -57: return "CL_INVALID_EVENT_WAIT_LIST";
			case -58: return "CL_INVALID_EVENT";
			case -59: return "CL_INVALID_OPERATION";
			case -60: return "CL_INVALID_GL_OBJECT";
			case -61: return "CL_INVALID_BUFFER_SIZE";
			case -62: return "CL_INVALID_MIP_LEVEL";
			case -63: return "CL_INVALID_GLOBAL_WORK_SIZE";
			case -64: return "CL_INVALID_PROPERTY";
			case -65: return "CL_INVALID_IMAGE_DESCRIPTOR";
			case -66: return "CL_INVALID_COMPILER_OPTIONS";
			case -67: return "CL_INVALID_LINKER_OPTIONS";
			case -68: return "CL_INVALID_DEVICE_PARTITION_COUNT";

			// extension errors
			case -1000: return "CL_INVALID_GL_SHAREGROUP_REFERENCE_KHR";
			case -1001: return "CL_PLATFORM_NOT_FOUND_KHR";
			case -1002: return "CL_INVALID_D3D10_DEVICE_KHR";
			case -1003: return "CL_INVALID_D3D10_RESOURCE_KHR";
			case -1004: return "CL_D3D10_RESOURCE_ALREADY_ACQUIRED_KHR";
			case -1005: return "CL_D3D10_RESOURCE_NOT_ACQUIRED_KHR";
			default: return "Unknown OpenCL error";
		}
	}



	static bool CheckError (cl_int error, char *info = 0)
	{
		if (error != CL_SUCCESS)
		{
			char *sourceCode = (char*) GetErrorString (error);
			printf ("! Error CL_Helper: %s: %s\n", info, sourceCode);
			return 1;
		}
		return 0;
	}



	static int DisplayDevice (cl_platform_id platform, cl_device_id device_id)
	{
		cl_int status;
		
		// Get platform name
		char platformVendor[1024];
		status = clGetPlatformInfo (platform, CL_PLATFORM_VENDOR, sizeof(platformVendor), platformVendor, NULL);
		
		char platformProfile[1024];
		status |= clGetPlatformInfo (platform, CL_PLATFORM_PROFILE, sizeof(platformProfile), platformProfile, NULL);
		
		char platformVersion[1024];
		status |= clGetPlatformInfo (platform, CL_PLATFORM_VERSION, sizeof(platformVersion), platformVersion, NULL);
		
		if (CheckError (status, "DisplayDevices: clGetPlatformInfo failed.")) return 0;
		SystemTools::Log ("\nSelected Platform Vendor: %s \nProfile: %s \nVersion: %s \n", 
			platformVendor, platformProfile, platformVersion);

		// Get number of devices available
		
		char deviceName[1024];
		status = clGetDeviceInfo(device_id, CL_DEVICE_NAME, sizeof(deviceName), deviceName, NULL);
		SystemTools::Log ("\nDevice: %s\n", deviceName);
		
		char deviceVersion[1024];
		status = clGetDeviceInfo(device_id, CL_DEVICE_VERSION, sizeof(deviceVersion), deviceVersion, NULL);
		SystemTools::Log ("Version: %s\n", deviceVersion);
		
		cl_uint adressBits;
		status = clGetDeviceInfo(device_id, CL_DEVICE_ADDRESS_BITS, sizeof(adressBits), &adressBits, NULL);
		SystemTools::Log ("Adress Bits: %i\n", adressBits);
	
		char deviceExtensions[1024];
		status = clGetDeviceInfo(device_id, CL_DEVICE_EXTENSIONS, sizeof(deviceExtensions), deviceExtensions, NULL);
		SystemTools::Log ("Extensions: %s\n", deviceExtensions);
	
		cl_ulong globalCacheSize;
		status = clGetDeviceInfo(device_id, CL_DEVICE_GLOBAL_MEM_CACHE_SIZE, sizeof(globalCacheSize), &globalCacheSize, NULL);
		SystemTools::Log ("Global Cache Size: %i\n", globalCacheSize);

		cl_uint globalCacheLine;
		status = clGetDeviceInfo(device_id, CL_DEVICE_GLOBAL_MEM_CACHELINE_SIZE, sizeof(globalCacheLine), &globalCacheLine, NULL);
		SystemTools::Log ("Cache Line: %i\n", globalCacheLine);

		cl_ulong localMemSize;
		status = clGetDeviceInfo(device_id, CL_DEVICE_LOCAL_MEM_SIZE, sizeof(localMemSize), &localMemSize, NULL);
		SystemTools::Log ("Local Memory Size: %i\n", localMemSize);

		size_t maxWorkGroupSize;
		status = clGetDeviceInfo(device_id, CL_DEVICE_MAX_WORK_GROUP_SIZE, sizeof(maxWorkGroupSize), &maxWorkGroupSize, NULL);
		SystemTools::Log ("Max Work Group Size: %i\n", maxWorkGroupSize);

		size_t maxWorkItemSizes[4]={0,0,0,0};
		status = clGetDeviceInfo(device_id, CL_DEVICE_MAX_WORK_ITEM_SIZES, sizeof(maxWorkItemSizes), maxWorkItemSizes, NULL);
		SystemTools::Log ("Max Work Item Sizes: [%i,%i,%i]\n", maxWorkItemSizes[0], maxWorkItemSizes[1], maxWorkItemSizes[2]);

		size_t maxImageWidth;
		status = clGetDeviceInfo(device_id, CL_DEVICE_IMAGE2D_MAX_WIDTH, sizeof(maxImageWidth), &maxImageWidth, NULL);
		SystemTools::Log ("Max Image Width: %i\n", maxImageWidth);

		//size_t maxImageArraySize;
		//status = clGetDeviceInfo(device_id, CL_DEVICE_IMAGE_MAX_ARRAY_SIZE, sizeof(maxImageArraySize), &maxImageArraySize, NULL);
		//SystemTools::Log ("Max Image Array Size: %i\n", maxImageArraySize);

		if (CheckError (status, "DisplayDevices: clGetDeviceInfo failed.")) return 0;

		SystemTools::Log ("\n");
		return 1;
	}


	static int DisplayPlatforms (cl_platform_id *platforms, cl_int num)
	{
		cl_int status;
		
		for (int i=0; i<num; i++)
		{
			cl_platform_id platform = platforms[i];
			cl_device_type deviceType = CL_DEVICE_TYPE_ALL;

			// Get platform name
			char platformVendor[1024];
			status = clGetPlatformInfo (platform, CL_PLATFORM_VENDOR, sizeof(platformVendor),
									   platformVendor, NULL);
			if (CheckError (status, "DisplayDevices: clGetPlatformInfo failed.")) return 0;
			SystemTools::Log ("\nAvailable Platform Vendor (%i): %s\n", i, platformVendor);

			// Get number of devices available
			cl_uint deviceCount = 0;
			status = clGetDeviceIDs(platform, deviceType, 0, NULL, &deviceCount);
			if (CheckError (status, "DisplayDevices: clGetDeviceIDs failed.")) return 0;
			cl_device_id* deviceIds = (cl_device_id*)malloc(sizeof(cl_device_id) *
									  deviceCount);
			//CHECK_ALLOCATION (deviceIds, "Failed to allocate memory(deviceIds)");
			// Get device ids
			status = clGetDeviceIDs(platform, deviceType, deviceCount, deviceIds, NULL);
			if (CheckError (status, "DisplayDevices: clGetDeviceIDs failed.")) return 0;
			// Print device index and device names
			for(cl_uint i = 0; i < deviceCount; ++i)
			{
				char deviceName[1024];
				status = clGetDeviceInfo(deviceIds[i], CL_DEVICE_NAME, sizeof(deviceName),
										 deviceName, NULL);
				if (CheckError (status, "DisplayDevices: clGetDeviceInfo failed.")) return 0;
				SystemTools::Log ("Device %i %s Device ID is %i\n", i, deviceName, deviceIds[i]);
			}
			free(deviceIds);
			SystemTools::Log ("\n");
		}
		return 1;
	}



	static void InitOpenCL (Factory &info)
	{
		info.ready = false;

		cl_platform_id platform_ids[16];
		cl_uint ret_num_devices;
		cl_uint ret_num_platforms;
		cl_int status;
		
		//cl_device_type deviceType = CL_DEVICE_TYPE_GPU;
 		cl_device_type deviceType = CL_DEVICE_TYPE_ALL;
		//cl_device_type deviceType = CL_DEVICE_TYPE_CPU;

		// Get Platform and Device Info
		status = clGetPlatformIDs (16, platform_ids, &ret_num_platforms);
		if (CheckError (status)) return;
		if (!ret_num_platforms) return;
		
		DisplayPlatforms (platform_ids, ret_num_platforms);

		//work:
		//cl_platform_id platform_id = platform_ids[2]; // intel cpu
		//cl_platform_id platform_id = platform_ids[1]; // amd cpu
 		//cl_platform_id platform_id = platform_ids[0]; // NV gpu
 
		//home:
		cl_platform_id platform_id = platform_ids[0]; // amd gpu
		//cl_platform_id platform_id = platform_ids[1]; // intel cpu
		
		
		status = clGetDeviceIDs (platform_id, deviceType, 1, &info.device_id, &ret_num_devices);
		if (CheckError (status)) return;

		DisplayDevice (platform_id, info.device_id);
 
		// Create OpenCL context
		info.context = clCreateContext (NULL, 1, &info.device_id, NULL, NULL, &status);
		if (CheckError (status)) return;

		// Create Command Queue
		info.command_queue = clCreateCommandQueue (info.context, info.device_id, 0, &status);
 		if (CheckError (status)) return;
	}

	static void ShutDown (Factory &info)
	{
//		clFlush (info.command_queue);
//		clFinish (info.command_queue);
//		ret = clReleaseKernel(kernel);
//		ret = clReleaseProgram(program);
//		clReleaseMemObject(memobj);
		clReleaseCommandQueue (info.command_queue);
		clReleaseContext (info.context);
	}


	static cl_program Compile (Factory &factory, char *filename, char *additional_compiler_options = "")
	{
		::std::ifstream file (filename, ::std::ifstream::in);
		if (file.rdstate() & ::std::ifstream::failbit)
		{
			SystemTools::Log ("! Error: CL_Helper::Compile: Error loading source code file : %s\n", filename);
			return 0;
		}
		::std::string sourceCode ((::std::istreambuf_iterator<char>(file)), ::std::istreambuf_iterator<char>());

		cl_program program = NULL;
		cl_int status;

		const char* code_array[] = {sourceCode.c_str()}; 
		const size_t code_array_size[] = {sourceCode.length()}; 
		program = clCreateProgramWithSource (factory.context, 1, code_array, code_array_size, &status);
		if (CheckError (status, "Compile: clCreateProgramWithSource failed.")) 
		{
			SystemTools::Log ("Source file: %s\nOptions: %s\n\n", filename, additional_compiler_options);
			return NULL;
		}

		//status = clBuildProgram (program, 1, &factory.device_id, NULL, NULL, NULL);
		//status = clBuildProgram (program, 1, &factory.device_id, "-cl-opt-disable", NULL, NULL);
		//status = clBuildProgram (program, 1, &factory.device_id, "-cl-strict-aliasing", NULL, NULL);

		std::string default_options = "-cl-fast-relaxed-math -cl-mad-enable -cl-denorms-are-zero -cl-finite-math-only ";
		std::string includeDir = "-I C:\\dev\\pengII\\cl_program\\ ";
		std::string options = includeDir + default_options + std::string(additional_compiler_options);

		status = clBuildProgram (program, 1, &factory.device_id, options.c_str(), NULL, NULL);
		if (CheckError (status, "Compile: clBuildProgram failed.")) 
		{
			SystemTools::Log ("Source file: %s\nOptions: %s\n\n", filename, additional_compiler_options);
			cl_build_status build_status;

			clGetProgramBuildInfo (program, factory.device_id, CL_PROGRAM_BUILD_STATUS, sizeof(cl_build_status), &build_status, NULL);

			char *build_log;

			size_t ret_val_size;
			clGetProgramBuildInfo (program, factory.device_id, CL_PROGRAM_BUILD_LOG, 0, NULL, &ret_val_size);
			build_log = new char[ret_val_size+2];
			clGetProgramBuildInfo (program, factory.device_id, CL_PROGRAM_BUILD_LOG, ret_val_size, build_log, NULL);
			build_log[ret_val_size] = '\n';
			build_log[ret_val_size+1] = '\0';
			SystemTools::Log (build_log);
			delete[] build_log;

			return NULL;
		}
 
		return program;
	}

	static cl_kernel CreateKernel (cl_program program, char *kernelName, cl_device_id device_id, bool logInfo = true)
	{
		cl_kernel kernel = NULL;
 		cl_int status;

		kernel = clCreateKernel (program, kernelName, &status);
		if (CheckError (status, "CreateKernel")) return NULL;

		if (logInfo)
		{
			size_t workGroupSize = 0;
			clGetKernelWorkGroupInfo (kernel, device_id, CL_KERNEL_WORK_GROUP_SIZE, sizeof(size_t), (void*)&workGroupSize, NULL);
			size_t compileWorkGroupSize[3] = {0,0,0};
			clGetKernelWorkGroupInfo (kernel, device_id, CL_KERNEL_COMPILE_WORK_GROUP_SIZE, sizeof(size_t)*3, (void*)&compileWorkGroupSize, NULL);
			cl_ulong localMemSize = 0;
			clGetKernelWorkGroupInfo (kernel, device_id, CL_KERNEL_LOCAL_MEM_SIZE, sizeof(cl_ulong), (void*)&localMemSize, NULL);
				
			SystemTools::Log ("Kernel %s Max Work Group Size: %i  Compile Work Group Size: [%i,%i,%i]  Local Memory Size: %i\n", kernelName, workGroupSize, 
				compileWorkGroupSize[0], compileWorkGroupSize[1], compileWorkGroupSize[2], localMemSize);
		}
 
		return kernel;
	}

	static int NumDeviceComputeUnits (cl_device_id device_id)
	{
		cl_int maxComputeUnits;
		clGetDeviceInfo(
			device_id,
			CL_DEVICE_MAX_COMPUTE_UNITS,
			sizeof(cl_uint),
			&maxComputeUnits,
			NULL);
		return maxComputeUnits;
	}

	static int NumDeviceMaxWorkItemSize (cl_device_id device_id, int dim = 0)
	{
		cl_int maxWorkItemSize[3];
		clGetDeviceInfo(
			device_id,
			CL_DEVICE_MAX_WORK_ITEM_SIZES,
			sizeof(cl_uint) * 3,
			&maxWorkItemSize,
			NULL);
		return maxWorkItemSize[dim];
	}

	
}